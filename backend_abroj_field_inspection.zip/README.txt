# ABROJ Field Inspection API (Backend)
1) Create MySQL DB and import `schema.sql`.
2) Copy `.env.example` to `.env` and fill credentials.
3) Hostinger: create Node.js app pointing to this folder (app start file: `server/app.js`).
4) App will install dependencies from `package.json` automatically.
5) Ensure `fonts/Roboto-Regular.ttf` and `fonts/Roboto-Bold.ttf` exist (place your Arabic-capable TTFs here if needed).

Default users (after schema import):
- Manager: manager@abroj.com / 123456
- Employee: employee@abroj.com / 123456
