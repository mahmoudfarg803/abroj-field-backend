-- Create database first (if not exists)
-- CREATE DATABASE abroj_field CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE abroj_field;

CREATE TABLE IF NOT EXISTS roles (
  id TINYINT PRIMARY KEY,
  name VARCHAR(20) NOT NULL UNIQUE
);
INSERT IGNORE INTO roles (id, name) VALUES (1,'admin'),(2,'manager'),(3,'employee');

CREATE TABLE IF NOT EXISTS users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  phone VARCHAR(30),
  role_id TINYINT NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  manager_id INT NULL,
  is_active TINYINT(1) DEFAULT 1,
  FOREIGN KEY (role_id) REFERENCES roles(id),
  FOREIGN KEY (manager_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS companies (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(200) NOT NULL,
  email VARCHAR(160),
  phone VARCHAR(30),
  address VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS branches (
  id INT PRIMARY KEY AUTO_INCREMENT,
  company_id INT NOT NULL,
  name VARCHAR(160) NOT NULL,
  location VARCHAR(160),
  FOREIGN KEY (company_id) REFERENCES companies(id)
);

CREATE TABLE IF NOT EXISTS branch_recipients (
  id INT PRIMARY KEY AUTO_INCREMENT,
  branch_id INT NOT NULL,
  recipient_name VARCHAR(160) NOT NULL,
  recipient_role VARCHAR(100),
  email VARCHAR(160),
  phone VARCHAR(30),
  notify_email TINYINT(1) DEFAULT 1,
  notify_whatsapp TINYINT(1) DEFAULT 0,
  FOREIGN KEY (branch_id) REFERENCES branches(id)
);

CREATE TABLE IF NOT EXISTS tasks (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(160) NOT NULL,
  is_active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS visits (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  branch_id INT NOT NULL,
  employee_id INT NOT NULL,
  started_at DATETIME NOT NULL,
  ended_at DATETIME NULL,
  status ENUM('draft','submitted','approved','sent') DEFAULT 'draft',
  FOREIGN KEY (branch_id) REFERENCES branches(id),
  FOREIGN KEY (employee_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS visit_inventory_items (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  visit_id BIGINT NOT NULL,
  item_name VARCHAR(200) NOT NULL,
  color VARCHAR(80),
  size VARCHAR(40),
  system_qty DECIMAL(12,3) DEFAULT 0,
  actual_qty DECIMAL(12,3) DEFAULT 0,
  diff_qty DECIMAL(12,3) AS (actual_qty - system_qty) STORED,
  FOREIGN KEY (visit_id) REFERENCES visits(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS visit_cash (
  visit_id BIGINT PRIMARY KEY,
  system_balance DECIMAL(14,2) DEFAULT 0,
  actual_balance DECIMAL(14,2) DEFAULT 0,
  sales_amount DECIMAL(14,2) DEFAULT 0,
  diff_amount DECIMAL(14,2) AS (actual_balance - system_balance) STORED,
  FOREIGN KEY (visit_id) REFERENCES visits(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS visit_notes (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  visit_id BIGINT NOT NULL,
  note_text TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (visit_id) REFERENCES visits(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notifications (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  type ENUM('visit_start','visit_end','submitted','approved','sent') NOT NULL,
  actor_user_id INT NOT NULL,
  branch_id INT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_read TINYINT(1) DEFAULT 0,
  FOREIGN KEY (actor_user_id) REFERENCES users(id)
);

-- Seed sample data (adjust for production)
INSERT INTO companies (name,email,phone,address) VALUES
  ('Panda Juice','owner@panda-juice.com',NULL,NULL)
  ON DUPLICATE KEY UPDATE name=name;

INSERT INTO branches (company_id, name, location)
SELECT c.id, 'فرع خِطلة طبيعية','الخبر' FROM companies c WHERE c.name='Panda Juice'
ON DUPLICATE KEY UPDATE name=name;

INSERT INTO branches (company_id, name, location)
SELECT c.id, 'فرع القمر الصافي','الدمام' FROM companies c WHERE c.name='Panda Juice'
ON DUPLICATE KEY UPDATE name=name;

-- Create a default manager and employee (password: 123456)
-- Replace hashes with secure ones in production.

SET @manager_role = (SELECT id FROM roles WHERE name='manager');
SET @employee_role = (SELECT id FROM roles WHERE name='employee');

INSERT INTO users (full_name,email,phone,role_id,password_hash)
VALUES ('مدير عام','manager@abroj.com',NULL,@manager_role,'$2b$12$NSQHGEa9399YbuGHzeJn2e1sJP1GwnbIgzExwS3m9KpRUivDbg21W')
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);

SET @mgr_id = (SELECT id FROM users WHERE email='manager@abroj.com');

INSERT INTO users (full_name,email,phone,role_id,password_hash,manager_id)
VALUES ('موظف زيارات','employee@abroj.com',NULL,@employee_role,'$2b$12$NSQHGEa9399YbuGHzeJn2e1sJP1GwnbIgzExwS3m9KpRUivDbg21W',@mgr_id)
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);

-- Link recipients to each branch (emails)
INSERT INTO branch_recipients (branch_id, recipient_name, recipient_role, email, phone, notify_email, notify_whatsapp)
SELECT b.id, 'Management','Manager','manager@abroj.com',NULL,1,0 FROM branches b
ON DUPLICATE KEY UPDATE recipient_name=recipient_name;

-- Default tasks (order your sections)
INSERT INTO tasks (name,is_active,sort_order) VALUES
  ('جرد الأصناف',1,1),
  ('جرد الخزنة',1,2),
  ('الملاحظات',1,3)
ON DUPLICATE KEY UPDATE name=name;
